package Services;

import Model.ParkVisitor;
import Model.Ticket;

public class TicketSeller {
    public void giveTicket(ParkVisitor v, Ticket t){
        v.buyTicket(t);
        System.out.println("Ticket sold.");
    }
    public void refundTicket(ParkVisitor v){
        v.cancelTicket();
        System.out.println("Refund done.");
    }
    public void takePayment(double amount){
        System.out.println("Payment received:"+ amount);
    }
    public void returnPayment(double amount){
        System.out.println("Returned:"+ amount);
    }
    public void showSales(String day){
        System.out.println("Sales Report-" + day);
        System.out.println("Tickets:");
    }
}
