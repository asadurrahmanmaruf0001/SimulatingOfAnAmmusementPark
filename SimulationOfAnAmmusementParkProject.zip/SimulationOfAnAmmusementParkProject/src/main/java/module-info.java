module com.example.simulationofanammusementparkproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.simulationofanammusementparkproject to javafx.fxml;
    exports com.example.simulationofanammusementparkproject;
}