package com.example.simulationofanammusementparkproject;

import Model.Feedback;
import Model.ParkVisitor;
import Model.Ticket;
import Services.TicketSeller;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your name");
        String name = sc.nextLine();
        ParkVisitor visitor = new ParkVisitor(name);
        System.out.println("Enter ride name");
        String rideName=sc.nextLine();
        System.out.println("Enter ticket price");
        double price = sc.nextDouble();
        sc.nextLine();
        Ticket ticket = new Ticket(rideName,price);
        TicketSeller seller = new TicketSeller();
        seller.giveTicket(visitor,ticket);
        seller.takePayment(ticket.getPrice());
        visitor.checkRide();
        System.out.println("Write your feedback");
        String message = sc.nextLine();
        System.out.println("Give rating (1-5)");
        int rating = sc.nextInt();
        Feedback feedback= new Feedback(message,rating);
        visitor.giveFeedback(feedback);
        seller.showSales("Today");
        seller.refundTicket(visitor);
    }
}