package com.example.simulationofanammusementparkproject;

public class MainController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}