package Model;

public class Feedback {
    private String message;
    private int rating;
     public Feedback(String message, int rating){
         this.message = message;
         this.rating = rating;
     }
     public void showFeedback(){
         System.out.println("Feedback:" + message + " (Rating :" +rating + "/5)");
     }
}
