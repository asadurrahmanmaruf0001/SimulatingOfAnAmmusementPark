package Model;

public class Ticket {
    private String rideName;
    private double price;

    public Ticket(String rideName,double price){
        this.rideName = rideName;
        this.price = price;
    }
    public String getRideName(){
        return rideName;
    }
    public double getPrice(){
        return price;
    }

}
