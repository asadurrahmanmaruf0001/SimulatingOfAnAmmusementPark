package Model;

public class ParkVisitor {
    private String name;
    private Ticket ticket;
    private Feedback feedback;

    public ParkVisitor(String name){
        this.name = name;
    }
    public void buyTicket(Ticket t){
        ticket = t;
        System.out.println(name+ "bought a ticket for"+ ticket.getRideName());
    }
    public void cancelTicket(){
        if (ticket!= null) {
            System.out.println(name + "canceled the ticket");
            ticket = null;
        }
        else{
            System.out.println("No ticket to cancel");
        }
    }
    public void checkRide(){
        if (ticket != null) {
            System.out.println("Ride" + ticket.getRideName() + "is ready.");
        }
        else {
            System.out.println("You have no ticket");
        }
    }
    public void giveFeedback(Feedback f){
        feedback = f ;
        feedback.showFeedback();
    }
}
